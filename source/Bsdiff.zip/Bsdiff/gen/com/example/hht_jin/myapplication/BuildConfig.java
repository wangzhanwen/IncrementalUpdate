/** Automatically generated file. DO NOT MODIFY */
package com.example.hht_jin.myapplication;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}